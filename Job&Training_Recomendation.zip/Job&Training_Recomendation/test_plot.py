import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report, accuracy_score
import dash
from dash import dcc, html, Input, Output, State

# Load dataset
data = pd.read_csv('competency_diagnostic_dataset.csv')

# Drop unnecessary columns
data = data.drop(['Name'], axis=1)

# Encode categorical variables
label_encoders = {}
categorical_columns = ['Field of Study', 'Job Recommendations', 'Training Recommendations']
for col in categorical_columns:
    le = LabelEncoder()
    data[col] = le.fit_transform(data[col])
    label_encoders[col] = le

# Features and targets
X = data.drop(['Job Recommendations', 'Training Recommendations'], axis=1)
y_job = data['Job Recommendations']
y_training = data['Training Recommendations']

# Train-test split
X_train_job, X_test_job, y_train_job, y_test_job = train_test_split(X, y_job, test_size=0.2, random_state=42)
X_train_training, X_test_training, y_train_training, y_test_training = train_test_split(X, y_training, test_size=0.2, random_state=42)

# Train Random Forest for Job Recommendations
job_model = RandomForestClassifier(random_state=42)
job_model.fit(X_train_job, y_train_job)

# Train Random Forest for Training Recommendations
training_model = RandomForestClassifier(random_state=42)
training_model.fit(X_train_training, y_train_training)

# Define function for recommendations
def recommend(candidate):
    candidate_df = pd.DataFrame([candidate])
    for col, le in label_encoders.items():
        if col in candidate_df.columns:
            try:
                candidate_df[col] = le.transform(candidate_df[col])
            except ValueError:
                candidate_df[col] = -1  # Handle unseen labels
    
    job_rec = job_model.predict(candidate_df)
    training_rec = training_model.predict(candidate_df)

    job_rec_label = label_encoders['Job Recommendations'].inverse_transform(job_rec)[0]
    training_rec_label = label_encoders['Training Recommendations'].inverse_transform(training_rec)[0]

    return job_rec_label, training_rec_label

# Dash app
app = dash.Dash(__name__)

app.layout = html.Div(
    style={
        'background': 'linear-gradient(to bottom, #141e30, #243b55)',
        'minHeight': '100vh',
        'padding': '20px',
        'color': 'white',
        'fontFamily': 'Arial, sans-serif',
    },
    children=[
        html.H1(
            "Job and Training Recommendation System",
            style={
                'textAlign': 'center',
                'color': '#ffffff',
                'marginBottom': '30px',
                'fontSize': '2.5em',
                'textShadow': '2px 2px #000000',
            },
        ),
        html.Div(
            style={
                'width': '50%',
                'margin': 'auto',
                'padding': '20px',
                'backgroundColor': 'rgba(255, 255, 255, 0.1)',
                'borderRadius': '10px',
            },
            children=[
                html.Div(
                    style={'marginBottom': '15px', 'border': '1px solid white', 'padding': '10px', 'borderRadius': '5px'},
                    children=[
                        html.Label("Age:", style={'fontWeight': 'bold'}),
                        dcc.Input(id='age', type='number', placeholder="Enter Age", style={'width': '100%'}),
                    ],
                ),
                html.Div(
                    style={'marginBottom': '15px', 'border': '1px solid white', 'padding': '10px', 'borderRadius': '5px'},
                    children=[
                        html.Label("Field of Study:", style={'fontWeight': 'bold'}),
                        dcc.Dropdown(
                            id='field_of_study',
                            options=[{'label': field, 'value': field} for field in label_encoders['Field of Study'].classes_],
                            placeholder="Select Field of Study",
                            style={'width': '100%'},
                        ),
                    ],
                ),
                html.Div(
                    style={'marginBottom': '15px', 'border': '1px solid white', 'padding': '10px', 'borderRadius': '5px'},
                    children=[
                        html.Label("Experience (Years):", style={'fontWeight': 'bold'}),
                        dcc.Input(id='experience', type='number', placeholder="Enter Experience (Years)", style={'width': '100%'}),
                    ],
                ),
                html.Div(
                    style={'marginBottom': '15px', 'border': '1px solid white', 'padding': '10px', 'borderRadius': '5px'},
                    children=[
                        html.Label("Technical Skills (0-100):", style={'fontWeight': 'bold'}),
                        dcc.Input(id='technical_skills', type='number', placeholder="Enter Technical Skills Score", style={'width': '100%'}),
                    ],
                ),
                html.Div(
                    style={'marginBottom': '15px', 'border': '1px solid white', 'padding': '10px', 'borderRadius': '5px'},
                    children=[
                        html.Label("Communication Skills (0-100):", style={'fontWeight': 'bold'}),
                        dcc.Input(id='communication_skills', type='number', placeholder="Enter Communication Skills Score", style={'width': '100%'}),
                    ],
                ),
                html.Div(
                    style={'marginBottom': '15px', 'border': '1px solid white', 'padding': '10px', 'borderRadius': '5px'},
                    children=[
                        html.Label("Problem-Solving Skills (0-100):", style={'fontWeight': 'bold'}),
                        dcc.Input(id='problem_solving_skills', type='number', placeholder="Enter Problem-Solving Skills Score", style={'width': '100%'}),
                    ],
                ),
                html.Div(
                    style={'marginBottom': '15px', 'border': '1px solid white', 'padding': '10px', 'borderRadius': '5px'},
                    children=[
                        html.Label("Teamwork (0-100):", style={'fontWeight': 'bold'}),
                        dcc.Input(id='teamwork', type='number', placeholder="Enter Teamwork Score", style={'width': '100%'}),
                    ],
                ),
                html.Div(
                    style={'marginBottom': '15px', 'border': '1px solid white', 'padding': '10px', 'borderRadius': '5px'},
                    children=[
                        html.Label("Overall Score (0-100):", style={'fontWeight': 'bold'}),
                        dcc.Input(id='overall_score', type='number', placeholder="Enter Overall Score", style={'width': '100%'}),
                    ],
                ),
                html.Button(
                    'Submit', id='submit-button', n_clicks=0,
                    style={
                        'width': '100%',
                        'padding': '10px',
                        'backgroundColor': '#007BFF',
                        'color': 'white',
                        'fontSize': '16px',
                        'fontWeight': 'bold',
                        'border': 'none',
                        'borderRadius': '5px',
                        'cursor': 'pointer',
                    },
                ),
            ],
        ),
        html.Div(id='output', style={'marginTop': '20px', 'textAlign': 'center', 'fontSize': '20px'}),
    ],
)

@app.callback(
    Output('output', 'children'),
    Input('submit-button', 'n_clicks'),
    State('age', 'value'),
    State('field_of_study', 'value'),
    State('experience', 'value'),
    State('technical_skills', 'value'),
    State('communication_skills', 'value'),
    State('problem_solving_skills', 'value'),
    State('teamwork', 'value'),
    State('overall_score', 'value')
)
def update_output(n_clicks, age, field_of_study, experience, technical_skills, communication_skills, problem_solving_skills, teamwork, overall_score):
    if n_clicks > 0:
        if None in [age, field_of_study, experience, technical_skills, communication_skills, problem_solving_skills, teamwork, overall_score]:
            return "Please fill out all fields before submitting."

        candidate = {
            'Age': age,
            'Field of Study': field_of_study,
            'Experience (Years)': experience,
            'Technical Skills': technical_skills,
            'Communication Skills': communication_skills,
            'Problem-Solving Skills': problem_solving_skills,
            'Teamwork': teamwork,
            'Overall Score': overall_score
        }

        job, training = recommend(candidate)
        return f"Recommended Job: {job} | Recommended Training: {training}"

# Run the app
if __name__ == '__main__':
    app.run_server(debug=True)
